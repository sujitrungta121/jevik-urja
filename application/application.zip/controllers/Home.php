<?php
require APPPATH.'controllers/MainController.php';
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends MainController{


    public function __construct(){
        parent::__construct(); 
        $this->load->library("session");
        $this->load->helper("site");

    }

    function cat_list_recursive(){
        $this->load->model("Api_model","am");
        $data=$this->am->category_list_recursive(0);
        echo "<pre>";
        print_r($data);

    }

    function index($output="html"){
    	$this->load->helper("form");
    	$this->load->model("Api_model","am");
        $data["category_list_recursive"]=$this->am->category_list_recursive(0);
    	$data["category_list"]=$category_list=$this->am->category_list(array("parent_id"=>0));
    	$array=array();
		$count=0;
		foreach($category_list as $list){
			$array[$count]=(array)$list;
            $category_ids=$this->am->get_category_chain($list->category_id);
            $category_ids[]=$list->category_id;
			$array[$count]["products"]=$this->am->product_list(array("category_id"=>$category_ids,"limit"=>12,"offset"=>0));
			$count++;
		}

		$data["category_data_list"]=$array;

    	$data["banner_list"]=$this->am->banner_list();
    	$data["brand_list"]=$this->am->brand_list(array("frontend_display"=>1));
        if($output=="array"){
            echo "<pre>";
            print_r($data);
            exit();
        }
    	
    	
    	$this->load->view("frontend/index",$data);
    }


    function product($id=""){
        $this->load->helper("form");
    	$this->load->model("Api_model","am");
        $data["category_list_recursive"]=$this->am->category_list_recursive(0);
    	$data["banner_list"]=$this->am->banner_list();
    	$data["brand_list"]=$this->am->brand_list();
    	$data["category_list"]=$this->am->category_list(0);
    	$data["details"]=$details=$this->am->product_details($id);
    	$data["product_list"]=$this->am->product_list(array("category_id"=>$details["category_id"],"limit"=>10,"offset"=>0,"exclude_product_id"=>$details["product_id"]));
    	/*echo "<pre>";
    	print_r($data); exit();*/
    	$this->load->view("frontend/product",$data);
    }

    function checkout(){
         $this->load->helper("form");
        $this->load->model("Api_model","am");
        $data["category_list_recursive"]=$this->am->category_list_recursive(0);
        $data["banner_list"]=$this->am->banner_list();
        $data["brand_list"]=$this->am->brand_list();
        $data["category_list"]=$this->am->category_list(0);
        $data["state_list"]=$this->am->state_list(101);
        $this->load->view("frontend/checkout",$data);
    }

    function product_list(){
        $this->load->model("Api_model","am");
        $search_params=$_GET;
        if(isset($search_params["category_id"])){
            $data["filter_category_data"]=$this->am->category_list_recursive($search_params["category_id"]);
            $data["main_category_data"]=$this->am->specific_category_data($search_params["category_id"]);
        }
        /*echo "<pre>";
        print_r($data);exit();*/
        $this->load->helper("form");
        $this->load->helper("site");
        $array=get_Url_query_string();
        //echo $array; exit();
        $this->am->reset_category_list_recursive();
        $data["category_list_recursive"]=$this->am->category_list_recursive(0);
        $data["brand_list"]=$this->am->brand_list();
        $data["category_list"]=$this->am->category_list(0);
        $this->load->view("frontend/product-list",$data);
    }

    function complete_order(){
        $payment_mode=$this->input->post("payment_mode");
        $address_id=$this->input->post("address_id");
        $this->load->library("session");
        $user_id=$this->session->userdata("user_id");
        $this->load->model("Api_model","am");
        $order_id=$this->am->complete_order($payment_mode,$address_id,$user_id);
        if($order_id){
           $this->session->set_flashdata("msg","<h2>Your Order Has Been Placed Successfully.</h2>Your Order Id is ".$order_id);
        }else{
           $this->session->set_flashdata("msg","<h2>Unable To Place The Order .</h2>Please Retry");
        }
         redirect("Home/info");
    }


}