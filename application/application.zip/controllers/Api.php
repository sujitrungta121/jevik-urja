<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Api extends CI_Controller{

	public function __construct(){
        parent::__construct(); 
        $this->load->library("session");
        ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);

    }


	function registration(){
		//exit();
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');

		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		$this->form_validation->set_rules('mobile', 'Mobile No.', 'trim|required');
		$this->form_validation->set_rules('fcm_token', 'FCM Token', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');

		if($this->form_validation->run()===FALSE){
			echo json_encode(array("status"=>"failed","status_code"=>0,"msg"=>validation_errors()));
			exit();
		}
		$referral_code=$this->input->post("referral_code");
		$name=$this->input->post("name");
		$email=$this->input->post("email");
		$mobile_no=$this->input->post("mobile");
		$password=$this->input->post("password");
		$password=password_hash($password, PASSWORD_DEFAULT);
		$fcm=$this->input->post("fcm_token");
		$time=date("Y-m-d H:i:s");
		//echo "i am working ";

		$this->load->model("Api_model","am");
		if($this->am->mobile_exist($mobile_no)>0){
			echo json_encode(array("status"=>"failed","status_code"=>0,"msg"=>"Mobile No. Allready Exist"));
			exit();
		}
		if($this->am->email_exist($email)>0){
			echo json_encode(array("status"=>"failed","status_code"=>0,"msg"=>"Email Id Allready Exist"));
			exit();
		}	
		$id=$this->am->save_registration_data($name,$email,$mobile_no,$password,$referral_code,$time,$fcm);
		if($id>0){
			$device_info=$this->am->specific_user_device_data($id);
			echo json_encode(array("status"=>"success","status_code"=>1,"msg"=>"Registration Data Saved Successfully","details"=>array("user_id"=>$device_info->user_id,"token"=>$device_info->access_token)));
		}else{
			echo json_encode(array("status"=>"failed","status_code"=>0,"msg"=>"Unable To Save Registration_data"));
		}
	}


	function dashboard($output="json"){
		$token=$this->input->get_request_header('token', TRUE);
		//$token="0ef78478e94f986112d8af26ab18ce35";
		$this->load->model("Api_model","am");
		if($this->am->token_exist($token)==0){
			echo json_encode(array("status"=>"failed","status_code"=>0,"msg"=>"Not Authorized"));
			exit();
		}
		$user_details=$this->am->user_details_by_token($token);
		$cart_count=$this->am->cart_item_count($user_details["user_id"]);
		$wallet_balance=$this->am->user_wallet_balance($user_details["user_id"]);
		$category_list=$this->am->category_list(array("limit"=>9,"parent_id"=>0));

		$array=array();
		$count=0;
		foreach($category_list as $list){
			$array[$count]=(array)$list;
			$array[$count]["products"]=$this->am->product_list(array("category_id"=>$list->category_id,"limit"=>6,"offset"=>0));
			$count++;
		}
		$banner_list=$this->am->banner_list();
		$brand_list=$this->am->brand_list();

		$data=array("details"=>$array,"banners"=>$banner_list,"brands"=>$brand_list,"user_details"=>
				array(
					"user_id"=>$user_details["user_id"],
					"name"=>$user_details["name"],
					"email"=>$user_details["email"],
					"mobile"=>$user_details["mobile"],
					"cart_count"=>$cart_count,
					"wallet_balance"=>$wallet_balance
				));

		if($output=="json"){
			echo json_encode($data);
		}else{
			echo "<pre>";
			print_r($data);
		}
	}

	function sendOTP(){
		$mobile_no=$this->input->post("mobile_no");
		$otp_code=rand(100000,999999);
		$this->load->library("Sms");
		$this->sms->send_sms($mobile_no,"GOMART OTP : ".$otp_code);
		$this->load->model("Api_model","am");
		$save=$this->am->saveOTP($otp_code,$mobile_no);
		if($save){
			echo json_encode(array("status"=>"success","status_code"=>1,"msg"=>"OTP sent successfully"));
		}else{
			echo json_encode(array("status"=>"failed","status_code"=>0,"msg"=>"Unable To Sent OTP"));
		}
	}

	function verifyOTP(){
		$mobile_no=$this->input->post("mobile_no");
		$otp_code=$this->input->post("otp_code");
		$this->load->model("Api_model","am");
		if($this->am->OTPExist($otp_code,$mobile_no)==1){
			$this->am->updateOTPStatus($mobile_no,2);
			echo json_encode(array("status"=>"success","status_code"=>1,"msg"=>"OTP Matched successfully"));
		}else{
			echo json_encode(array("status"=>"failed","status_code"=>0,"msg"=>"OTP Mismatched"));
		}

	}

	/*function sms_check(){
		$this->load->library("Sms");
		$this->sms->send_sms(7003782339,"dummy sms from gomart");
	}*/

	function login(){
		$this->load->model("Api_model","am");
		$user_name=$this->input->post("user_name");
		$password=$this->input->post("password");
		$fcm=$this->input->post("fcm_token");
		if($this->am->login_data_exist($user_name)==1){
			$user_data=$this->am->user_data($user_name);
			$authenticated=password_verify($password, $user_data["password"]);
			if($authenticated){
				if($this->am->device_data_exist($user_data["user_id"],$fcm)>0){
					$token=$this->am->refresh_device_token($user_data["user_id"],$fcm);
				}else{
					$id=$this->am->create_user_device_data($user_data["user_id"],$fcm);
					$device_info=$this->am->specific_user_device_data($id);
					$token=$device_info->access_token;
				}
				echo json_encode(array("status"=>"success","status_code"=>1,"msg"=>"Login Done Successfully","details"=>array("user_id"=>$user_data["user_id"],"token"=>$token)));
				exit();
			}
		}
		echo json_encode(array("status"=>"failed","status_code"=>0,"msg"=>"Unable To Login"));
	}


	function product_list(){
		$category_id=$this->input->post("category_id");
		$limit=$this->input->post("limit");
		$offset=$this->input->post("offset");
		$offset=$limit*$offset;
		$this->load->model("Api_model","am");
		$totalRecords=$this->am->count_product_list(array("category_id"=>$category_id));
		$list=$this->am->product_list(array("category_id"=>$category_id,"offset"=>$offset,"limit"=>$limit));
		echo json_encode(array("status"=>"success","status_code"=>1,"listData"=>$list,"totalRecords"=>$totalRecords));
	}


	function addToCart($source="web"){
		$product_id=$this->input->post("product_id");
		$variant_id=$this->input->post("variant_id");
		$qty=$this->input->post("qty");
		if(!$this->input->post("operator")){
			$operator="+";
		}else{
			$operator=$this->input->post("operator");
		}
		$this->load->library("session");
		$login_state=1;
		if(!$this->session->userdata("user_id")){
			$login_state=0;
		}
		$user_id=$this->session->userdata("user_id");
		if($user_id==0 || is_null($user_id)){
			$login_state=0;
		}
		if($login_state==0){
			echo json_encode(array("status"=>"failed","status_code"=>0,"type"=>2,"msg"=>"No Active Login found"));
			exit();
		}


		$this->load->model("Api_model","am");
		$cart_id=$this->am->addToCart($product_id,$variant_id,$qty,$user_id,$operator);
		if($cart_id){
			$count=$this->am->cartDetailsDataCount($cart_id);
			$list=$this->am->cartDetailsData($user_id);
			echo json_encode(array("status"=>"success","status_code"=>1,"msg"=>"Product Added To Cart","item_count"=>$count,"list"=>$list));
		}else{
			echo json_encode(array("status"=>"failed","status_code"=>0,"type"=>1,"msg"=>"Unable To Add Product"));
		}

	}

	function removeFromCart(){
		$order_details_id=$this->input->post("oid");
		$this->load->library("session");
		$user_id=$this->session->userdata("user_id");
		$this->load->model("Api_model","am");
		$deleted=$this->am->removeFromCart($order_details_id,$user_id);
		if($deleted){
			$list=$this->am->cartDetailsData($user_id);
			echo json_encode(array("status"=>"success","status_code"=>1,"msg"=>"Product Removed From Cart","list"=>$list));
		}else{
			echo json_encode(array("status"=>"failed","status_code"=>0,"msg"=>"Unable To Remove Product From Cart"));
		}
		
	}

	function cartDetails(){
		$this->load->library("session");
		$user_id=$this->session->userdata("user_id");
		$this->load->model("Api_model","am");
		$list=$this->am->cartDetailsData($user_id);
		echo json_encode(array("status"=>"success","list"=>$list));	
	}


	function productOptions($product_id){
		$this->load->model("Api_model","am");
		$list=$this->am->productOptions($product_id);
		/*echo json_encode(array("status"=>"success","list"=>$list));	
		echo "<br>";*/
		$array=array();
		foreach($list as $list){
			if($list["old_price"]==0){
				$disc=0;
			}else{
				$disc=($list["old_price"]-$list["price"])*100/$list["old_price"];
			}
			
			$array[]=array("option_value_row_id"=>$list["option_value_row_id"],"option_id"=>$list["option_id"],"value_name"=>$list["value_name"],"old_price"=>$list["old_price"],"price"=>$list["price"],"pr_value_id"=>$list["pr_value_id"],"disc"=>$disc,"base"=>$list["base"]);
		}

		echo json_encode(array("status"=>"success","list"=>$array));	
	}

	function addressList(){
		$this->load->library("session");
		$user_id=$this->session->userdata("user_id");
		$this->load->model("Api_model","am");
		$address_list=$this->am->address_list($user_id);
		echo json_encode(array("status"=>"success","address_list"=>$address_list));
	}


	function saveAddress(){
		$name=$this->input->post("name");
		$mobile_no=$this->input->post("mobile_no");
		$pin_code=$this->input->post("pin_code");
		$locality=$this->input->post("locality");
		$address=$this->input->post("address");
		$city=$this->input->post("city");
		$state_id=$this->input->post("state_id");
		$landmark=$this->input->post("landmark");
		$this->load->library("session");
		$user_id=$this->session->userdata("user_id");
		$this->load->model("Api_model","am");
		//$saved_id=0;
		$saved_id=$this->am->save_address($name,$mobile_no,$pin_code,$locality,$address,$city,$state_id,$landmark,$user_id);
		$address_list=$this->am->address_list($user_id);
		echo json_encode(array("status"=>"success","address_id"=>$saved_id,"address_list"=>$address_list));
		
		/*$this->load->model("Api_model","am");
		$this->am->*/
	}

	function filterProductList(){
		$search_params=$_POST;
		$products=array();
		$deep=0;
		//print_r($search_params);
		$this->load->model("Api_model","am");
		$array=array();
		$temp_array=array();
		$category_ids=array();
		
		if(isset($search_params["category_id"])){
			$cat_list=array();
			foreach($search_params["category_id"] as $category_id){
				$category_ids=$this->am->get_category_chain($category_id);
				//print_r($category_ids);
				$category_ids[]=$category_id;
				$cat_list=array_merge($cat_list,$category_ids);
			}
			$array["category_id"]=$cat_list;
		}

		if(isset($search_params["price"])){
			$deep=1;
			foreach($search_params["price"] as $price_range){
				$segments=explode("-",$price_range);
				$array["price_from"]=$segments[0];
				$array["price_to"]=$segments[1];
				$pr=$this->am->product_list($array);
				$products=array_merge($products,$pr);
			}
		}

		//print_r($array); exit();
		if($deep==0){
			$products=$this->am->product_list($array);
		}

		$this->am->create_temp_tbl_for_product_filter($products);

		if(isset($search_params["order_by"]) && $search_params["order_by"]!=""){
			$segments=explode("-",$search_params["order_by"]);
			$temp_array["order_by_field"]=$segments[0];
			$temp_array["ordering"]=$segments[1];
		}

		$disc=array();
		if(isset($search_params["discount"])){
			foreach($search_params["discount"] as $disc_data){
				$segments=explode("-", $disc_data);
				$start=$segments[0];
				$end=$segments[1];
				for($i=$start;$i<$end;$i++){
					$disc[]=$i;
				}
			}	
			$temp_array["disc"]=$disc;

		}

		$products=$this->am->get_temp_product_filter_data($temp_array);

		
		echo json_encode(array("status"=>"success","status_code"=>1,"products"=>$products));
	}


}