<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Controller {


		function __construct()
		{
			parent::__construct();
			$this->load->library("session");
			$this->load->helper("url");
			$this->load->helper("form");
			if(! $this->session->userdata('validated')){
            redirect('admin/account/login');
        }
		
		}
 
 
	public function index(){
 		$this->load->model("User_model","um");
 		$data["list"]=$this->um->user_list(array("user_type_id"=>2));
 		$this->load->view("admin/user_list",$data);
	}

	function status_update(){
		//print_r($_POST);exit();
		$user_id=$this->input->post("user_id");
		$status=$this->input->post("status");
		$this->load->model("User_model","um");
		$updated=$this->um->status_update($status,$user_id);
		if($updated){
			$this->session->set_flashdata('action_message', 'User Data Updated Successfully');
			$this->session->set_flashdata('action_message_type', 'success');
		}else{
			$this->session->set_flashdata('action_message', 'Unable To Updated User Data');
			$this->session->set_flashdata('action_message_type', 'danger');
		}
		redirect("admin/User");
	}
	
	
  
}
