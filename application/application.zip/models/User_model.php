<?php
class User_model extends CI_Model
{
    public function __construct(){
        // Call the Model constructor
        parent::__construct();
        $this->load->database();
    }

    function user_list($args=array()){
        $this->db->select("name,email,mobile,referral_code,created_on,user_id,status");
        $this->db->from("user");
        $this->db->where("user_type_id",$args["user_type_id"]);
        $this->db->where("status !=",0);
        return $this->db->get()->result_array();
    }

    function status_update($status,$user_id){
        $data=$this->db->update("user",array("status"=>$status),array("user_id"=>$user_id),1);
        //echo $this->db->last_query(); exit();
        return $data;
    }
}
