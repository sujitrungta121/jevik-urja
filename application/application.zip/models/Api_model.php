<?php
class Api_model extends CI_Model{
    private $recursive_category_list=array();
    private $category_chain_data=array();
    public function __construct(){
        // Call the Model constructor
        parent::__construct();
        $this->load->database();
    }


    function create_user_device_data($user_id,$fcm){
        do{
            $token=time().rand(1000000,9999999);
            $token=md5($token);
        } while ($this->device_token_exist($token)>0);

        $this->db->insert("user_device",array("user_id"=>$user_id,"access_token"=>$token,"fcm_token"=>$fcm,"created_on"=>date("Y-m-d H:i:s")));
        return $this->db->insert_id();
    }


    function save_registration_data($name,$email,$mobile,$password,$referral_code,$time,$fcm,$id=""){
        $this->db->trans_begin();
        if($id==""){
            $this->db->insert("user",array("name"=>$name,"email"=>$email,"mobile"=>$mobile,"password"=>$password,"created_on"=>$time,"referral_code"=>$referral_code,"status"=>1));
            $user_id=$this->db->insert_id();
            $device_id=$this->create_user_device_data($user_id,$fcm);
        }
        if($this->db->trans_status()===FALSE){
            $this->db->trans_rollback();
            return false;
        }else{
            $this->db->trans_commit();
            return $device_id;
        }
    }

    /*function user_details_by_token($token){
        $this->db->select("ud.fcm_token,u.name,u.user_id");
        $this->db->from("user u");
        $this->db->join("user_device ud","ud.user_id=u.user_id","inner");
        $this->db->where("ud.access_token",$token);
        $this->db->where("u.status",1);
        return $this->db->get()->row_array();
    }
*/
    function device_token_exist($token){
        $this->db->select("count(id) as found");
        $this->db->from("user_device");
        $this->db->where("access_token",$token);
        return $this->db->get()->row()->found;
    }

    function specific_user_device_data($id){
        $this->db->select("*");
        $this->db->from("user_device");
        $this->db->where("id",$id);
        return $this->db->get()->row();
    }

    function mobile_exist($mob){
        $this->db->select("count(user_id) as found");
        $this->db->from("user");
        $this->db->where("mobile",$mob);
        return $this->db->get()->row()->found;
    }
    function email_exist($email){
        $this->db->select("count(user_id) as found");
        $this->db->from("user");
        $this->db->where("email",$email);
        return $this->db->get()->row()->found;
    }

    function category_list($args=array()){
        $this->db->select("cd.category_name,cd.category_id,c.main_image,c.banner_image,c.small_image");
        $this->db->from("category_description cd");
        $this->db->join("category c","c.id=cd.category_id","inner");
        $this->db->where("status",1);
        $this->db->where("cd.language_id",2);
        /*if($args["parent_id"]!=""){*/
            $this->db->where("c.parent_id",$args["parent_id"]);
        /*}*/
        if(isset($args["limit"]) && $args["limit"]!=""){
            $this->db->limit($args["limit"]);
        }
        return $this->db->get()->result();
    }

    function count_product_list($args=array()){
        $this->db->select("count(id) as found");
        $this->db->from("product");
        if(isset($args["category_id"]) && $args["category_id"]!=""){
            $this->db->where("category_id",$args["category_id"]);
        }
        return $this->db->get()->row()->found;
        
    }


    function product_list($args=array()){
        $this->db->select("cd.category_name,cd.category_id,pov.price,pov.old_price,p.id as product_id,p.stock,p.image,pd.name,ov.value_name as selected_option_name,pov.id as selected_option_id");
        $this->db->from("product p");
        $this->db->join("product_description pd","pd.product_id=p.id","inner");
         $this->db->join("category_description cd","cd.category_id=p.category_id and cd.language_id=2","inner");
        $this->db->join("product_option_value pov","pov.product_id=p.id and pov.base=1","inner");
        $this->db->join("option_value ov","ov.option_value_row_id=pov.value_id","inner");
        $this->db->where("pd.language_id",2);
        $this->db->where("status",1);
        if(isset($args["category_id"]) && !is_array($args["category_id"])){
            $this->db->where("p.category_id",$args["category_id"]);
        }
        if(isset($args["category_id"]) && is_array($args["category_id"])){
            $this->db->where_in("p.category_id",$args["category_id"]);
        }
        if(isset($args["price_from"]) && $args["price_from"]>0){
            $this->db->where("pov.price >=",$args["price_from"]);
        }
        if(isset($args["price_to"]) && $args["price_to"]>0){
            $this->db->where("pov.price <=",$args["price_to"]);
        }


        if(isset($args["exclude_product_id"]) && $args["exclude_product_id"]!=""){
            $this->db->where("p.id !=",$args["exclude_product_id"]);
        }
        if(isset($args["limit"]) && $args["limit"]!=""){
            $this->db->limit($args["limit"],$args["offset"]);
        }
        if(isset($args["order_by_field"]) && $args["order_by_field"]=="price"){
            $this->db->order_by("pov.price",$args["ordering"]);
        }
        $products=$this->db->get()->result_array();
        //echo $this->db->last_query(); exit();
        $array=array();
        $count=0;
        foreach($products as $pr){
            $array[$count]=$pr;
            $array[$count]["options"]=$this->product_options($pr["product_id"]);
            $count++;
        }
        return $array;

    }

    function product_options($product_id){
        $this->db->select("ov.value_name as option_name,pov.id,pov.price,pov.old_price");
        $this->db->from("product_option_value pov");
        $this->db->join("option_value ov","ov.option_value_row_id=pov.value_id","inner");
        $this->db->where("pov.product_id",$product_id);
        return $this->db->get()->result_array();

    }

    function banner_list(){
        $this->db->select("file_path");
        $this->db->from("banner");
        $this->db->where("status",1);
        return $this->db->get()->result_array();
    
    }

    function brand_list($args=array()){
        $this->db->select("b.id,b.image,bd.name");
        $this->db->from("brand b");
        $this->db->join("brand_description bd","bd.brand_id=b.id and bd.language_id=2","inner");
        if(isset($args["frontend_display"])){
            $this->db->where("b.frontend_display",$args["frontend_display"]);
        }
        return $this->db->get()->result_array();

    }

    function login_data_exist($user_name){
        $this->db->select("count(user_id) as found");
        $this->db->from("user");
        $this->db->where("email",$user_name);
        $this->db->or_where("mobile",$user_name);
        $this->db->where("status",1);
        return $this->db->get()->row()->found;
    }

    function user_data($user_name){
        $this->db->select("*");
        $this->db->from("user");
        $this->db->where("email",$user_name);
        $this->db->or_where("mobile",$user_name);
        $this->db->where("status",1);
        return $this->db->get()->row_array();
    }

    function device_data_exist($user_id,$fcm_token){
        $this->db->select("count(id) as found");
        $this->db->from("user_device");
        $this->db->where("fcm_token",$fcm_token);
        $this->db->where("user_id",$user_id);
        return $this->db->get()->row()->found;
    }


    function refresh_device_token($user_id,$fcm){

        do{
            $token=time().rand(1000000,9999999);
            $token=md5($token);
        } while ($this->device_token_exist($token)>0);
        $this->db->update("user_device",array("access_token"=>$token),array("user_id"=>$user_id,"fcm_token"=>$fcm),1);
        return $token;
    }


    function product_details($id){
        $this->db->select("cd.category_name,cd.category_id,pd.details,pov.price,pov.old_price,p.id as product_id,p.stock,p.image,pd.name,ov.value_name as selected_option_name,pov.id as selected_option_id ");
        $this->db->from("product p");
        $this->db->join("product_description pd","pd.product_id=p.id","inner");
        $this->db->join("category_description cd","cd.category_id=p.category_id and cd.language_id=2","inner");
        $this->db->join("product_option_value pov","pov.product_id=p.id and pov.base=1","inner");
        $this->db->join("option_value ov","ov.option_value_row_id=pov.value_id","inner");
        $this->db->where("pd.language_id",2);
        $this->db->where("p.id",$id);
        if(isset($args["category_id"]) && $args["category_id"]!=""){
            $this->db->where("p.category_id",$args["category_id"]);
        }
        if(isset($args["limit"]) && $args["limit"]!=""){
            $this->db->limit($args["limit"],$args["offset"]);
        }
        $product=$this->db->get()->row_array();
        //echo $this->db->last_query(); exit();
            $product["options"]=$this->product_options($id);
        return $product;
    }

    function product_option_details($option_id){
        $this->db->select("pov.*,ov.value_name");
        $this->db->from("product_option_value pov");
        $this->db->join("option_value ov","ov.option_value_id=pov.value_id","inner");
        $this->db->where("pov.id",$option_id);
        $data=$this->db->get()->row_array();
        //echo $this->db->last_query(); exit();
        return $data;
    }

    function removeFromCart($order_details_id,$user_id){
        return $this->db->delete("order_detail",array("oid"=>$order_details_id));
    }

    function addToCart($product_id,$variant_id,$qty,$user_id,$operator="+"){
        $this->db->trans_begin();
        if($this->cartDataExist($user_id)==0){
            $this->db->insert("order",array("customer_id"=>$user_id,"type"=>2,"date"=>date("Y-m-d H:i:s")));
            $id=$this->db->insert_id();
            $option_details=$this->product_option_details($variant_id);

            //print_r($option_details); exit();

            $this->db->insert("order_detail",array("order_id"=>$id,"product_id"=>$product_id,"count"=>$qty,"options"=>$variant_id,"total_price"=>$option_details["price"]*$qty,"unit_price"=>$option_details["price"]));



        }else{
            $cart_details=$this->cartDetails($user_id);
            $id=$cart_details->order_id;
            if($this->cartDetailsDataExist($id,$product_id,$qty,$variant_id)>0){
                //echo "exist ";
                $option_details=$this->product_option_details($variant_id);
                $price=$option_details["price"];               
                $this->db->set("count","count".$operator.$qty,FALSE);
                $this->db->set("total_price","total_price".$operator.$price,FALSE);
                $this->db->where("order_id",$id);
                $this->db->where("product_id",$product_id);
                $this->db->where("options",$variant_id);
                $this->db->update("order_detail");
                //echo $this->db->last_query(); exit();
            }else{
                 //echo "not exist ";
                $this->db->insert("order_detail",array("order_id"=>$id,"product_id"=>$product_id,"count"=>$qty,"options"=>$variant_id));
            }

        }
        if($this->db->trans_status()===FALSE){
            $this->db->trans_rollback();
            return false;
        }else{
            $this->db->trans_commit();
            return $id;
        }
    }

    function cartDataExist($user_id){
        $this->db->select("count(order_id) as found");
        $this->db->from("order");
        $this->db->where("customer_id",$user_id);
        $this->db->where("type",2);
        return $this->db->get()->row()->found;
    }


    function cartDetails($user_id){
       $this->db->select("*");
       $this->db->from("order");
       $this->db->where("customer_id",$user_id); 
       $this->db->where("type",2);
       return $this->db->get()->row();
    }

    function cartDetailsDataCount($order_id){
        $this->db->select("count(order_id) as found");
        $this->db->from("order_detail");
        $this->db->where("order_id",$order_id);
        return $this->db->get()->row()->found;
    }

    function cartDetailsData($user_id){
        $this->db->select("p.image,od.product_id,pd.name as product_name,pov.price,pov.old_price,od.count,od.options as variant_id,ov.value_name as variant_name,od.oid");
        $this->db->from("order_detail od");
        $this->db->join("order ord","ord.order_id=od.order_id and ord.type=2","inner");
        $this->db->join("product p","p.id=od.product_id","inner");
        $this->db->join("product_description pd","pd.product_id=od.product_id and pd.language_id=2","inner");
        $this->db->join("product_option_value pov","pov.id=od.options","inner");
        $this->db->join("option_value ov","ov.option_value_id=pov.value_id","inner");
        $this->db->where("ord.customer_id",$user_id);
        return $this->db->get()->result_array();
    }

    function cartDetailsAmtCount($user_id){
        $this->db->select("sum(total_price) as total");
        $this->db->from("order_detail od");
        $this->db->join("order ord","ord.order_id=od.order_id and ord.type=2","inner"); 
        $this->db->where("ord.customer_id",$user_id);
        return $this->db->get()->row()->total;
    }


    function cartDetailsDataExist($order_id,$product_id,$qty,$variant_id){
        $this->db->select("count(order_id) as found");
        $this->db->from("order_detail");
        $this->db->where("order_id",$order_id);
        $this->db->where("product_id",$product_id);
        $this->db->where("options",$variant_id);
        return $this->db->get()->row()->found;
    }

    function orderDetails($user_id){
       $this->db->select("*");
       $this->db->from("order");
       $this->db->where("customer_id",$user_id); 
       $this->db->where("type",2);
       return $this->db->get()->row();
    }

    function saveOTP($otp_code,$mobile_no){
        $this->db->trans_begin();
        $this->db->select("count(id) as found");
        $this->db->from("otp");
        $this->db->where("phone_no",$mobile_no);
        $found=$this->db->get()->row()->found;
        if($found==0){
            $this->db->insert("otp",array("phone_no"=>$mobile_no,"otp"=>$otp_code,"created_on"=>date("Y-m-d H:i:s"),"status"=>1));
        }else{
            $this->db->update("otp",array("otp"=>$otp_code,"created_on"=>date("Y-m-d H:i:s"),"status"=>1),array("phone_no"=>$mobile_no));
        }
        if($this->db->trans_status()===FALSE){
            $this->db->trans_rollback();
            return false;
        }else{
            $this->db->trans_commit();
            return true;
        }

    }

    function OTPExist($otp_code,$mobile_no){
        $this->db->select("count(id) as found");
        $this->db->from("otp");
        $this->db->where("otp",$otp_code);
        $this->db->where("phone_no",$mobile_no);
        $this->db->where("status",1);
        return $this->db->get()->row()->found;

    }

    function updateOTPStatus($mobile_no,$status){
        return $this->db->update("otp",array("status"=>2),array("phone_no"=>$mobile_no));
    }


    function productOptions($product_id){
        $this->db->select('option_value.*, product_option_value.*, product_option_value.id AS pr_value_id');
                $this->db->where('option_id', 25);
                $this->db->where('product_id', $product_id);
                $this->db->join('product_option_value', 'product_option_value.value_id = option_value.option_value_id');
                $this->db->where('language_id', 2);
                $query = $this->db->get("option_value");
                return $query->result_array();
    }

    function token_exist($token){
        $this->db->select("count(ud.id) as found");
        $this->db->from("user_device ud");
        $this->db->join("user u","u.user_id=ud.user_id and u.status=1","inner");
        $this->db->where("ud.access_token",$token);
        $this->db->where("ud.status",1);
        return $this->db->get()->row()->found;
    }



    function user_details_by_token($token){
        $this->db->select("ud.fcm_token,u.user_id,u.name,u.email,u.mobile");
        $this->db->from("user_device ud");
        $this->db->join("user u","u.user_id=ud.user_id and u.status=1","inner");
        $this->db->where("ud.access_token",$token);
        $this->db->where("ud.status",1);
        return $this->db->get()->row_array();
        
    }

    function user_wallet_balance($user_id){
        $this->db->select("(sum(cr)-sum(dr)) as balance");
        $this->db->from("wallet");
        $this->db->where("user_id",$user_id);
        return $this->db->get()->row()->balance;
    }

    function cart_item_count($user_id){
        $this->db->select("count(od.order_id) as found");
        $this->db->from("order_detail od");
        $this->db->join("order ord","ord.order_id=od.order_id","inner");
        $this->db->where("ord.type",2);
        $this->db->where("ord.customer_id",$user_id);
        return $this->db->get()->row()->found;
    }

    function category_list_recursive($parent_id=0){
        $this->db->select("cd.category_name,c.id as category_id,c.parent_id");
        $this->db->from("category_description cd");
        $this->db->join("category c","c.id=cd.category_id","inner");
        $this->db->where("c.status",1);
        $this->db->where("cd.language_id",2);
        $this->db->where("parent_id",$parent_id);
        $details=$this->db->get()->result_array();
        foreach($details as $det){
            $this->recursive_category_list[]=array("name"=>$det["category_name"],"category_id"=>$det["category_id"],"child_data"=>$this->category_list_recursive2($det["category_id"]));
        }

       return $this->recursive_category_list;

    }
    function reset_category_list_recursive(){
        $this->recursive_category_list=array();
    }

    function category_list_recursive2($parent_id=0){
        $this->db->select("cd.category_name,c.id as category_id,c.parent_id");
        $this->db->from("category_description cd");
        $this->db->join("category c","c.id=cd.category_id","inner");
        $this->db->where("c.status",1);
        $this->db->where("cd.language_id",2);
        $this->db->where("parent_id",$parent_id);
        $details=$this->db->get()->result_array();
        $array=array();
        $i=0;
        foreach($details as $det){
            $array[$i]=array("name"=>$det["category_name"],"category_id"=>$det["category_id"],"child_data"=>$this->category_list_recursive2($det["category_id"]));
            $i++;
        }

        return $array;
    }


    function get_category_chain($parent_id,$node=0){
        if($node==0){
            $this->category_chain_data=array();
        }
        $this->db->select("id");
        $this->db->from("category");
        $this->db->where("status",1);
        $this->db->where("parent_id",$parent_id);
        $details=$this->db->get()->result();
        foreach($details as $det){
            $this->category_chain_data[]=$det->id;
            $this->get_category_chain($det->id,1);
        }
        return $this->category_chain_data;  
    }

    function specific_category_data($cat_id){
        $this->db->select("category_id,category_name");
        $this->db->from("category_description");
        $this->db->where("category_id",$cat_id);
        return $this->db->get()->row_array();
    }

    function create_temp_tbl_for_product_filter($products){
        $this->db->query("DROP TEMPORARY TABLE IF EXISTS `temp_product_list`");
        $this->db->query("CREATE TEMPORARY TABLE `temp_product_list` (
         `product_id` int(10) NOT NULL,
         `category_name` varchar(200) NOT NULL,
         `category_id` int(10) NOT NULL,
         `price` double(12,2) NOT NULL,
         `old_price` double(12,2) NOT NULL,
         `disc` int(4) NOT NULL,
         `stock` int(10) NOT NULL,
         `image` text NOT NULL,
         `name` varchar(200) NOT NULL,
         `selected_option_name` varchar(200) NOT NULL,
         `selected_option_id` int(10) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=latin1");

        foreach($products as $pr){
            unset($pr["options"]);
            $pr["disc"]=($pr["old_price"]-$pr["price"])*100/$pr["old_price"];
            $this->db->insert("temp_product_list",$pr);
        }
    }

    function get_temp_product_filter_data($args){
        $this->db->select("*");
        $this->db->from("temp_product_list");
        if(isset($args["order_by_field"]) && $args["order_by_field"]!=""){
            $this->db->order_by($args["order_by_field"],$args["ordering"]);
        }

        if(isset($args["disc"])){
            $this->db->where_in("disc",$args["disc"]);
        }

        $products=$this->db->get()->result_array();
        //echo $this->db->last_query(); exit();
        $array=array();
        $count=0;
        foreach($products as $pr){
            $array[$count]=$pr;
            $array[$count]["options"]=$this->product_options($pr["product_id"]);
            $count++;
        }
        return $array;
    }

    function state_list($country_id){
        $this->db->select("*");
        $this->db->from("states");
        $this->db->where("country_id",$country_id);
        return $this->db->get()->result_array();
    }

    function save_address($name,$mobile_no,$pin_code,$locality,$address,$city,$state_id,$landmark,$user_id){
        $this->db->trans_begin();
        $this->db->insert("address",array("name"=>$name,"mobile_no"=>$mobile_no,"pin_code"=>$pin_code,"locality"=>$locality,"address"=>$address,"city"=>$city,"state_id"=>$state_id,"landmark"=>$landmark,"user_id"=>$user_id));

        if($this->db->trans_status()===false){
            $this->db->trans_rollback();
            return false;
        }else{
            $this->db->trans_commit();
            return $this->db->insert_id();
        }
    }

    function address_list($user_id){
        $this->db->select("a.*,s.name as state_name");
        $this->db->from("address a");
        $this->db->join("states s","s.id=a.state_id","inner");
        $this->db->where("a.user_id",$user_id);
        $this->db->where("a.status",1);
        return $this->db->get()->result_array();
        //echo $this->db->last_query(); exit();
    }

    function get_delivery_charge($amt){
        if($amt>499){
            return 0;
        }else{
            return 35;
        }
    }

    function complete_order($payment_mode,$address_id,$user_id){
        $this->db->trans_begin();
        $cart_id=$this->cartDetails($user_id);
        $total=$this->cartDetailsAmtCount($user_id);
        $delivery_charge=$this->get_delivery_charge($total);
        $grand_total=$total+$delivery_charge;
        $this->db->update("order",array("payment_type"=>$payment_mode,"type"=>1,"total"=>$total,"delivery_charges"=>$delivery_charge,"grand_total"=>$grand_total,"address_id"=>$address_id,"date"=>date("Y-m-d H:i:s")),array("order_id"=>$cart_id,"customer_id"=>$user_id));
        if($this->db->trans_status()===FALSE){
            $this->db->trans_rollback();
            return false;
        }else{
            $this->db->trans_commit();
            return $cart_id;
        }

    }



    /*function saveAddress(){

    }*/






}
