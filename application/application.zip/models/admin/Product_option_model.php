<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Product_option_model extends CI_Model { 

public function __construct(){
    // Call the Model constructor
    parent::__construct();
    $this->load->database();
}

  
 
function get_options($id){
				$this->db->select('product_option.*, option.*, option_description.*, product_option.id AS pr_opt_id');
				$this->db->where('product_option.product_id', $id);
				$this->db->where('option_description.language_id', 2);
				$this->db->join('option', 'option.id = product_option.option_id');
				$this->db->join('option_description', 'option_description.option_id = product_option.option_id');
				$query = $this->db->get("product_option");
				return $query->result();
 
}
function get_option_result($option_type){
				$this->db->select('option.*, option_description.*, option.id AS opt_value_id');
 				$this->db->where('option.option_type', $option_type);
 				$this->db->where('option_description.language_id',2);
				$this->db->join('option_description', 'option.id = option_description.option_id');
 				$query = $this->db->get("option");
				$data=$query->result();
				//echo $this->db->last_query();exit();
				return $data;
 
} 
 
 
function get_option_type_list(){
 				$query = $this->db->get("option");
				return $query->result();
 
} 

function product_option_exist($product_id){
	$this->db->select("count(*) as found");
	$this->db->from("product_option");
	$this->db->where("product_id",$product_id);
	return $this->db->get()->row()->found;
}

function product_option_value_exist($product_id){
	$this->db->select("count(*) as found");
	$this->db->from("product_option_value");
	$this->db->where("product_id",$product_id);
	return $this->db->get()->row()->found;
}
 public function add_new_option($data){
 	return $this->db->insert("product_option",array("product_id"=>$data['product_id'],"option_id"=>$data['option_id']));
 		/*return $this->db->query("INSERT INTO product_option SET product_id = '" . $data['product_id'] . "',  option_id = '" . $data['option_id'] . "'");*/
		
	
 }
 
 public function add_new_value($data){
 	$base=0;
 	if($this->product_option_value_exist($data['product_id'])==0){
 		$base=1;
 	}
 		return $this->db->query("INSERT INTO product_option_value SET product_id = '" . $data['product_id'] . "',  value_id = '" . $data['value_id'] . "', operation = '" . $data['operation'] . "', price = '" . $data['price'] . "',old_price = '" . $data['old_price'] . "',base = '" . $base . "'");
 	}

 
	
 public function value_update($data){  
 	$this->db->trans_begin();
	 for ($i = 0; $i < count($data['pr_value_id']); $i++) {
	 	if($data['pr_value_id'][$i]==$data["default"]){
	 		$base=1;
	 	}else{
	 		$base=0;
	 	}
	 	$this->db->update("product_option_value",
	 		array("price"=>$data['price'][$i],"old_price"=>$data['old_price'][$i],"base"=>$base),array("id"=>$data['pr_value_id'][$i])
	 	);

		/*$main_update = $this->db->query("UPDATE product_option_value SET operation = '".$data['operation'][$i]."', price = '".$data['price'][$i]."' WHERE id = '".$data['pr_value_id'][$i]."'");
	 
		if($main_update){
			return true;
		}*/
	 } 
	 if($this->db->trans_status()===FALSE){
	 	$this->db->trans_rollback();
	 	return false;
	 }else{
	 	$this->db->trans_commit();
	 	return true;
	 }
	}
	
 public function delete_value($data){
		$main_update = $this->db->query("DELETE FROM product_option_value WHERE id = '" . (int)$data . "'");

		echo $this->db->last_query(); exit();
		
		if($main_update){
			return true;
		}
 }
 
 public function delete($data){
		$main_update = $this->db->query("DELETE FROM product_option WHERE id = '" . (int)$data . "'");
		
		if($main_update){
			return true;
		}
 
 }
	function get_values($option_id, $product_id){
				$this->db->select('option_value.*, product_option_value.*, product_option_value.id AS pr_value_id');
				$this->db->where('option_id', $option_id);
				$this->db->where('product_id', $product_id);
				$this->db->join('product_option_value', 'product_option_value.value_id = option_value.option_value_id');
				$this->db->where('language_id', 2);
				$query = $this->db->get("option_value");
				return $query->result();


	}
	
	function get_values_list($option_id){
 				$this->db->where('option_id', $option_id);
 				$this->db->where('language_id', 2);
				$query = $this->db->get("option_value");
				return $query->result();


	}
  
}


    

 
 