  <?php $this->load->view('admin/header'); ?>
<div id="page-wrapper">

            <div class="container-fluid">
                        <h1 class="page-header">
                            Dashboard <small>// User List</small>
                        </h1>

		<hr>
						 <p class="text-right">
               <!-- Trigger the modal with a button -->

             </p>

  <table id="data-list" class="table table-bordered">
      <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Email</th>
          <th>Mobile Number</th>
          <th>Referral Code</th>
          <th>Entry Time</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
 <?php $i = 1; foreach($list AS $list) { ?>
 		 <tr>
     <td><?php echo $i;?></td>
     <td><?php echo $list["name"];?></td>
     <td><?php echo $list["email"];?></td>
     <td><?php echo $list["mobile"];?></td>
     <td><?php echo $list["referral_code"];?></td>
		 <td><?php echo $list["created_on"];?></td>
     <td>
       <?php if($list["status"]==1){
              echo "Active";
             }elseif($list["status"]==2){
              echo "Blocked";
             }
        ?>
     </td>
      <td>
        <?php echo form_open("admin/User/status_update");?>
        <?php if($list["status"]==2){?>
        <button type="submit" class="btn btn-success">
          Activate
        </button>
        <input type="hidden" name="user_id" value="<?php echo $list["user_id"];?>">
        <input type="hidden" name="status" value="1">
        <?php }elseif($list["status"]==1){?>
        <button type="submit" class="btn btn-warning">
          Block
        </button>
         <input type="hidden" name="status" value="2">
        <input type="hidden" name="user_id" value="<?php echo $list["user_id"];?>">
        <?php }?>
        <?php echo form_close();?>
        <?php echo form_open("admin/User/status_update");?>

        <button style="margin-top:5px;" type="submit" class="btn btn-danger" >
          <span class="glyphicon glyphicon-remove"></span>
          Delete
        </button>
        <input type="hidden" name="user_id" value="<?php echo $list["user_id"];?>">
         <input type="hidden" name="status" value="0">
        
       
        <?php echo form_close();?>
		  </td>

		 </tr>
 <?php $i++; } ?>
 
      </tbody>
    </table>


 

		 

 

   </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->


<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Pin Code</h4>
      </div>
      <div class="modal-body">
        
        <?php echo form_open("admin/Pin_code/save");?>
  <div class="form-group">
    <label for="email">Pin Code:</label>
    <input type="text" class="form-control" id="pin_code" name="pin_code">
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

 
 <script type="text/javascript">
  $(document).ready(function() {
    $('#data-list').dataTable();
  } );
</script>

  <?php $this->load->view('admin/footer'); ?>