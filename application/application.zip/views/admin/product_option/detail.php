  <?php $this->load->view('admin/header'); ?>
<div id="page-wrapper" ng-app="myApp" ng-controller="Ctrl">

            <div class="container-fluid">
                        <h1 class="page-header">
                            Dashboard <small>// Value List</small>
                        </h1>

		<form action="<?php echo $this->config->item('admin_url'); ?>product_option/value_update/<?php echo $option_id; ?>/<?php echo $product_id; ?>" method="post" accept-charset="utf-8" class="form-horizontal" role="form">				
		<hr>
 
  <table id="data-list" class="table table-bordered">
      <thead>
        <tr>
          <th>Name</th>
         <!--  <th>Operation</th> -->
          <th>Default</th>
          <th>Main Price</th>
          <th width="80px;">Discount %</th>
          <th>New Price</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>

 <!--  <?php // $i=0; foreach($values as $value){ $i++; ?> -->
 
 <tr ng-repeat="row in optionList">
 <td>{{row.value_name}}</td>
 <td>
  <input type="radio" name="default" value="{{row.pr_value_id}}" ng-checked="row.base=='1'" >
 <input type="hidden" class="form-control"  value="{{row.pr_value_id}}" name="pr_value_id[]">
 		<select name="operation[]" class="form-control" style="display: none;">
		<option value="+">+</option>
		<!-- <option value="-">-</option> -->
		</select>
</td>
  <td><input type="text" class="form-control"  name="old_price[]" ng-model="row.old_price" ></td>
  <td><input type="text" class="form-control" name="disc[]"   ng-model="row.disc" ng-value="0"></td>
  <td><input type="text" readonly="true" class="form-control" value="{{row.old_price-(row.old_price*row.disc/100)}}" name="price[]"></td>
  
 <td>
	<!-- <a href="<?php echo $this->config->item('admin_url'); ?>product_option/delete_value/<?php echo $value->pr_value_id; ?>"><span class="glyphicon glyphicon-remove"></span></a> -->

  <a href="<?php echo base_url("admin/product_option/delete_value/");?>{{row.pr_value_id}}"><span class="glyphicon glyphicon-remove"></span></a>


 </td>

 </tr>
 <?php // } ?>
 <tr>
 <td colspan="5">
      <p align="right"><button type="submit" class="btn btn-default">Update</button></p>
	  </td>
</tr>
	  </form>
	  
		<form action="<?php echo $this->config->item('admin_url'); ?>product_option/add_value/<?php echo $option_id; ?>/<?php echo $product_id; ?>" method="post" accept-charset="utf-8" class="form-horizontal" role="form">				

 <tr>
 <td>
		<select name="value_id" class="form-control">
		<option value=""></option>
  <?php foreach($value_list AS $values){ ?>
		<option value="<?php echo $values->option_value_id; ?>"><?php echo $values->value_name; ?></option>
		
		<?php } ?>
 		</select>
 <input type="hidden" name="option_id" value="<?php echo $option_id; ?>">
  <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">

 
 </td>
 <td>
		<select  name="operation" class="form-control" style="display: none;">
 
		<option value="+">+</option>
		<option value="-">-</option>
		</select>
</td>
  <td>
    <input  type="text" class="form-control" value="" name="old_price">
    </td>
  <td><input style="display: none;" type="text" class="form-control" value="" name="price"></td>
 <td>
      <p align="right"><button type="submit" class="btn btn-primary">Add New</button></p>

 </td>
 <td>
  <?php echo form_open("admin/Product/lists");?>
  <a href="<?php echo base_url("admin/Product/lists");?>">
   <button type="button" class="btn btn-success">Click Here To Back To Product List</button>
 </a>

 </td>

 </tr>
  </form>
      </tbody>
    </table>


 

		 

 

   </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

<script type="text/javascript">
  var app = angular.module('myApp', []);
  app.controller('Ctrl', function($scope, $http) {
    $scope.optionList=[];
    $scope.loadProductOptions=function(){
      //alert("sdaSDAS");
      $http.get("<?php echo base_url();?>Api/productOptions/<?php echo $product_id;?>")
        .then(function (response) {
        //alert(response);
        $scope.optionList = response.data.list;
      });
    }
     $scope.loadProductOptions();

    $scope.calc=function(row){
      var diff_amt=row.old_price-row.price;
      var percent=diff_amt*100/row.old_price;
      row.disc=percent;


    }
  })
</script>
 
  <?php $this->load->view('admin/footer'); ?>