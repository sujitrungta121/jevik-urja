<?php $this->load->view("frontend/common/header");?>
	
	<!-- banner part -->
	<section class="banner">
		<!-- <img src="<?php echo base_url();?>frontend/assets/images/slide.jpg" class="img-fluid"> -->
		<div class="flexslider">
			<ul class="slides">
				<?php foreach($banner_list as $banner){?>
				<li><img src="<?php echo $banner["file_path"];?>" /></li>
				<?php } ?>
			</ul>
		</div>
	</section>
	<!-- /end banner part -->
	
	<!-- trending product -->
	<section class="trending">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 text-center">
					<h2 class="title">Categories</h2>
				</div>
				<div class="col-xl-12">
					<div class="trending-pro">
						<!-- item looping start -->
						<?php //echo print_r($category_list);?>
						<?php foreach($category_list as $category_data){?>
						<div class="pro-item" >
							<a href="<?php echo base_url("Home/product_list?category_id=".$category_data->category_id);?>" title="">
								<img src="<?php echo $category_data->main_image;?>" alt="pro" class="img-fluid">
								<div class="text-pt">
									<h5><?php echo $category_data->category_name;?></h5>
								</div>
							</a>
						</div>
						<?php } ?>
						<!-- item looping end -->
						<!-- <div class="pro-item">
							<a href="#" title="">
								<img src="<?php echo base_url();?>frontend/assets/images/pro2.jpg" alt="pro" class="img-fluid">
								<div class="text-pt">
									<h5>FOODGRAINS, OIL & MASALA</h5>
								</div>
							</a>
						</div>
						<div class="pro-item">
							<a href="#" title="">
								<img src="<?php echo base_url();?>frontend/assets/images/pro3.jpg" alt="pro" class="img-fluid">
								<div class="text-pt">
									<h5>EGGS, MEAT AND FISH</h5>
								</div>
							</a>
						</div>
						<div class="pro-item">
							<a href="#" title="">
								<img src="<?php echo base_url();?>frontend/assets/images/pro4.jpg" alt="pro" class="img-fluid">
								<div class="text-pt">
									<h5>PERSONAL CARE</h5>
								</div>
							</a>
						</div> -->
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- //trending product -->

	<!-- product part -->
	<?php foreach($category_data_list as $category_data){?>
	<section class="product-main">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
					<h2 class="title"><?php echo $category_data["category_name"];?> <a href="<?php echo base_url("Home/product_list?category_id=".$category_data["category_id"]);?>" class="float-right v-btn btn"><i class="fas fa-eye mr-2"></i> View All</a></h2>
				</div>
				<div class="col-xl-12">
					<div class="item-slide3 owl-carousel owl-theme products">
						<!-- loop start -->
						<?php foreach($category_data["products"] as $pr){?>
						<?php $this->load->view("frontend/common/product_display_inside_list",array("pr"=>$pr));?>
						<?php } ?>
						<!-- loop end -->
												
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php } ?>
	
	<!-- //product part -->
	
	<!-- top brands -->
	<section class="top-charts">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 text-center">
					<h2 class="title">Top Brands</h2>
				</div>
				<div class="col-xl-12">
					<div class="brands-item" >
						<?php foreach($brand_list as $brand){?>
						<div class="item"><a href="#"><img src="<?php echo $brand["image"];?>" alt="" class="img-fluid"></a></div>
						<?php } ?>

					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- //top brands -->
	<?php $this->load->view("frontend/common/footer");?>
</main>


<!-- Login Modal -->
<?php $this->load->view("frontend/common/login_modal");?>

<!-- Cart Modal -->
<?php $this->load->view("frontend/common/cart_modal");?>

<!-- onload modal 
<div class="login">
	<div class="modal fade" id="homemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
		  <div class="modal-body">
			<div class="col-12 p-0 text-center">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
				<img src="<?php echo base_url();?>frontend/assets/images/adver.jpg" alt="" class="img-fluid">
			</div>
		  </div>
		</div>
	  </div>
	</div>
</div> -->



<script src="<?php echo base_url("frontend/assets/js/jquery.mobile-menu.min.js");?>"></script>    
<!-- Banner Slider js script file-->
<script  src="<?php echo base_url("frontend/assets/js/jquery.flexslider.js");?>"></script>
<script  src="<?php echo base_url("frontend/assets/js/scripts.js");?>"></script>
<!-- owl.carousel js -->
<script src="<?php echo base_url("frontend/assets/js/owl.carousel.min.js");?>"></script> 
<script src="<?php echo base_url("frontend/assets/js/angular.min.js");?>"></script>
<script type="text/javascript">
	var baseUrl="<?php echo base_url();?>";
</script>
<script src="<?php echo base_url("frontend/assets/js/pages/common.js");?>"></script> 
<script>
  $(document).ready(function() {
  	var owl = $('.item-slide3');
	    owl.owlCarousel({
	      items:4,
	      loop:true,
	      nav:true,
	      margin: 10,
	      dots:false,
	      autoplay:false,
	      navText: ["<i class='ti-angle-left'></i>", "<i class='ti-angle-right'></i>"],
	      responsive: {
	        0: {
	          items: 1
	        }
	        , 480: {
	          items: 2
	        }
	        , 768: {
	          items: 3
	        }
	        , 1200: {
	          items: 5
	        }
	      }
	    })



  })
</script>
</body>
</html>