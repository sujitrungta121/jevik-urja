<div class="login">
	<div class="modal fade" id="loginmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
		  <div class="modal-body">
			<div class="col-12 mb-4 text-center">
				<h5>SIGN IN</h5>
				<p>Not Registered? Sign Up</p>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="login-main">
				<div class="login-item text-center">
					<?php echo form_open("",array("id"=>"loginForm"));?>
						<input type="email" name="user_name" class="form-control" placeholder="EMAIL OR MOBILE NO">
						<input type="password" name="password" class="form-control" placeholder="PASSWORD">
						<p class="text-right">Forgot Password?</p>
						<button type="button" ng-click="submitLoginData()" class="log-btn mt-2">SIGN IN</button>
					<?php echo form_close();?>
				</div>
				<div class="login-item text-center">
					<?php echo form_open("Account/registration",array("id"=>"regisForm"));?>
						<input type="text" name="name" class="form-control" required placeholder="NAME">
						<!-- <input type="text" class="form-control" required placeholder="LAST NAME"> -->
						<input type="email" name="email" class="form-control" required placeholder="EMAIL">
						<input type="password" name="password" class="form-control" required placeholder="PASSWORD">
						<input type="text" name="mobile" class="form-control" required placeholder="MOBILE">
						<input type="text" name="referral_code" class="form-control" required placeholder="REFFERER CODE">
						<!-- <div>
							<div class="custom-control custom-radio custom-control-inline">
							  <input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input" checked>
							  <label class="custom-control-label" for="customRadioInline1">MALE</label>
							</div>
							<div class="custom-control custom-radio custom-control-inline">
							  <input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input">
							  <label class="custom-control-label" for="customRadioInline2">FEMALE</label>
							</div>
						</div> -->
						<small>By Signing up you will agree Privacy Policy and Terms of Conditions.</small>
						<button type="button" ng-click="submitRegisData();" class="log-btn mt-3">SIGN UP</button>
					<?php echo form_close();?>
				</div>
			</div>
		  </div>
		</div>
	  </div>
	</div>
</div>